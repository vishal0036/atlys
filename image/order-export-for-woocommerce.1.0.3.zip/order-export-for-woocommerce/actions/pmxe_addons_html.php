<?php

function pmwoe_pmxe_addons_html() {
    echo "<input type='hidden' id='pmxe_woocommerce_order_addon_installed' value='1'>";
}